
// firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getDatabase, ref, set, push, onChildAdded } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-database.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCl7xiTXB_vgb7NSkBkfwHUp2uBEODYAd4",
  authDomain: "go-pro-dc14e.firebaseapp.com",
  databaseURL: "https://go-pro-dc14e-default-rtdb.firebaseio.com",
  projectId: "go-pro-dc14e",
  storageBucket: "go-pro-dc14e.firebasestorage.app",
  messagingSenderId: "969794238680",
  appId: "1:969794238680:web:b70d00e4587213315abfad",
  measurementId: "G-G24GR5LMYC"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

export { db, ref, set, push, onChildAdded, auth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged };
